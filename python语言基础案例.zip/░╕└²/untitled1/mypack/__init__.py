from mypack.test2 import test1
print('__mypack__',test1)