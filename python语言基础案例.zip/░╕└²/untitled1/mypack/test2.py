# coding: utf-8
# author: yopoing
test1 = "maizixueyuan..."