#!/usr/bin/env python
# coding: utf-8
# author: yopoing

# 单行注释
# 多对多的
print('hello world')
print('hello world2')
print('hello worl3', '888', '999')

"""
多行注释（文本注释）
"""

