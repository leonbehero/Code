# coding: utf-8
# author: yopoing
"""
while 条件表达式：
    满足条件执行的代码
else:
    不满足条件退出循环的时候执行的代码
"""
# mystr = 'maizixueyuan666'
# # 起始位置
# i = 0
# while i < len(mystr):
#     print(mystr[i])
#     i += 1
# else:
#     print('循环顺利执行并结束')

# while 1==1:
#     print('ok')

# mystr = 'maizixueyuan666'
# for (i, v) in enumerate(mystr):
#     print(i, v)
#     if i==5:
#         break
# else:
#     print('循环顺利执行并结束')

"""
使用while和for分别完成从1累加到100求奇数和的例子
"""
# # 初始值
# num = 1
# # 求和值
# sum = 0
# while num <= 100:
#     if num%2 != 0:
#         sum += num
#     num += 1
# print(sum)

# sum = 0
# for num in range(1, 101):
#     if num % 2 != 0:
#         sum += num
# print(sum)
